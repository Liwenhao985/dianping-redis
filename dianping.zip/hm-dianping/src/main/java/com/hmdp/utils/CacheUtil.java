package com.hmdp.utils;

import cn.hutool.core.util.StrUtil;
import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.hmdp.dto.Result;
import com.hmdp.entity.Shop;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;

import static cn.hutool.poi.excel.sax.AttributeName.t;
import static com.hmdp.utils.RedisConstants.*;

@Component
public class CacheUtil {

    @Autowired
    private StringRedisTemplate stringRedisTemplate;

    private static final ExecutorService CACHE_REBUILD_EXECUTOR = Executors.newFixedThreadPool(10);

    public void set(String key, Object value, Long time, TimeUnit unit) {
        stringRedisTemplate.opsForValue().set(key, JSONUtil.toJsonStr(value), time, unit);
    }

    public void setWithLogicalExpire(String key, Object value, Long time, TimeUnit unit) {
        // 设置逻辑过期
        RedisData redisData = new RedisData();
        redisData.setData(value);
        redisData.setExpireTime(LocalDateTime.now().plusSeconds(unit.toSeconds(time)));
        // 写入Redis
        stringRedisTemplate.opsForValue().set(key, JSONUtil.toJsonStr(redisData));
    }

    public <ID, T> T getWithLogicalExpire(ID id, Class<T> type, String prefix, Long time, TimeUnit unit,Function<ID,  T> dbFallback) throws InterruptedException {
        String key=prefix+id;
        //  1.查询redis是否有缓存
        String json = stringRedisTemplate.opsForValue().get(key);
        if(StrUtil.isBlank(json)){
            return null;
        }
        //  2.有缓存，检查是否逻辑过期
        //  把jason转换成LogicalExpire
        RedisData redisData = JSONUtil.toBean(json, RedisData.class);
        T t=JSONUtil.toBean((JSONObject) redisData.getData(), type);
        if(redisData.getExpireTime().isAfter(LocalDateTime.now())){
            //  2.1未过期，获取并返回结果
            return t;
        }
        //  3.过期，尝试获取锁
        //  这里lock有问题，写死了
        String lock = LOCK_SHOP_KEY + id;
        boolean isLock = tryLock(lock);
        if(!isLock){
            //  3.1没有获取互斥锁，说明正在查询数据库，直接获取旧结果
            return t;
        }
        //  3.2获取锁成功之后应该再检查缓存是否过期，没过期则无需重建缓存
        //......
        //  4.获取锁成功，开启新线程进行数据库查询并写入缓存
        CACHE_REBUILD_EXECUTOR.submit(()->{
            try {
                T t2 = dbFallback.apply(id);
                setWithLogicalExpire(key, t2, time, unit);
            } finally {
                unlock(lock);
            }
        });
        //  5.返回旧结果
        return t;
    }

    public <ID, T> T getWithSaveNull(ID id, Class<T> type, String prefix, Long time,TimeUnit unit,Function<ID,  T> dbFallback,  Function<ID,  T> dbNullFallback) throws InterruptedException {
        String key=prefix+id;
        //  1.查询redis是否有缓存
        String json = stringRedisTemplate.opsForValue().get(key);
        if(StrUtil.isNotBlank(json)){
            T t=JSONUtil.toBean(json, type);
            return t;
        }
        //  2.检查是否为“”
        if(json!= null){
            return null;
        }
        // 3.不存在，根据id查询数据库
        T t = dbFallback.apply(id);
        // 4.不存在，返回错误
        if (t == null) {
            // 将空值写入redis
            stringRedisTemplate.opsForValue().set(key, "", CACHE_NULL_TTL, TimeUnit.MINUTES);
            // 返回错误信息
            return null;
        }
        // 5.存在，写入redis
        this.set(key, t, time, unit);
        return t;
    }

    private void unlock(String lock) {
        stringRedisTemplate.delete(lock);
    }

    private boolean tryLock(String lock) {
        //锁的过期时间一般比业务语句多10多倍
        boolean flag = Boolean.TRUE.equals(stringRedisTemplate.opsForValue().setIfAbsent(lock, "1",10L, TimeUnit.SECONDS));
        return flag;
    }
}
