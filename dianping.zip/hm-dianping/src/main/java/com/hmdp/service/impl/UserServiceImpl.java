package com.hmdp.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.bean.copier.CopyOptions;
import cn.hutool.core.lang.UUID;
import cn.hutool.core.util.RandomUtil;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.hmdp.dto.LoginFormDTO;
import com.hmdp.dto.Result;
import com.hmdp.dto.UserDTO;
import com.hmdp.entity.User;
import com.hmdp.mapper.UserMapper;
import com.hmdp.service.IUserService;
import com.hmdp.utils.RegexPatterns;
import com.hmdp.utils.RegexUtils;
import com.hmdp.utils.UserHolder;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.connection.BitFieldSubCommands;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpSession;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import static com.hmdp.utils.RedisConstants.*;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author 虎哥
 * @since 2021-12-22
 */
@Slf4j
@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements IUserService {

    @Autowired
    private StringRedisTemplate  stringRedisTemplate;
    public static String CODE_EXPIRE;
    @Override
    public Result sendCode(String phone) {
        //1.校验手机号
        if(RegexUtils.isPhoneInvalid(phone)){
            //手机号不符合，返回错误信息
            return Result.fail("手机号格式错误");
        }
        //2.手机号合法，生成6位数的验证码
        CODE_EXPIRE= RandomUtil.randomNumbers(6);
        //3.保存验证码到Redis
        stringRedisTemplate.opsForValue().set(LOGIN_CODE_KEY+ phone, CODE_EXPIRE, LOGIN_CODE_TTL, TimeUnit.MINUTES);
        //4.发送验证码(一般是通过阿里云这些第三方来发送)
        //项目开发中直接调用短信服务发送即可，这里模拟一下
        log.debug("发送短信验证码成功，验证码：{}",CODE_EXPIRE);
        return null;
    }

    @Override
    public Result login(LoginFormDTO loginForm, HttpSession session) {
        //1.校验手机号
        String phone = loginForm.getPhone();
        if(RegexUtils.isPhoneInvalid(phone)){
            //手机号不符合，返回错误信息
            return Result.fail("手机号错误");
        }
        //2.校验验证码
        String code = loginForm.getCode();
        String cacheCode = stringRedisTemplate.opsForValue().get(LOGIN_CODE_KEY + phone);
        if(cacheCode == null || !cacheCode.equals(code)){
            return Result.fail("验证码错误");
        }
        //3.查询用户
        User user = query().eq("phone", phone).one();
        if(user == null){
            //4.不存在，创建新用户并保存
            user = createUserWithPhone(phone);
        }
        //5.保存用户到Redis
        //存储UserDTO对象而不是User对象，可以节省内存，同时避免敏感信息暴露
        //5.1.随机生成token，作为登录令牌(hutool的UUID)
        String token = UUID.randomUUID().toString(true);
        //5.2.将User对象转为Hash存储(hutool的BeanUtil)
        //Long类型无法自动转换成字符串，所以需要自己写
        UserDTO userDTO = BeanUtil.copyProperties(user, UserDTO.class);
        Map<String, Object> userMap = BeanUtil.beanToMap(userDTO,new HashMap<>(),
                CopyOptions.create()
                        .setIgnoreNullValue(true)
                        .setFieldValueEditor((fieldName, fieldValue) -> fieldValue.toString()));
        //5.3.存储到Redis中
        String tokenKey= LOGIN_USER_KEY + token;
        stringRedisTemplate.opsForHash().putAll(tokenKey, userMap);
        //5.4.设置有效期
        //要注意，这个key的保存时间要不断刷新，所以要在拦截器中实现
        stringRedisTemplate.expire(tokenKey, LOGIN_CODE_TTL, TimeUnit.MINUTES);

        return Result.ok(token);
    }

    @Override
    public Result queryUserById(Long userId){
        // 查询详情
        User user = getById(userId);
        if (user == null) {
            return Result.ok();
        }
        UserDTO userDTO = BeanUtil.copyProperties(user, UserDTO.class);
        // 返回
        return Result.ok(userDTO);
    }

    @Override
    public Result sign() {
        //1.获取当前登录用户
        Long userId = UserHolder.getUser().getId();
        // 2.获取当前日期
        String now = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMM"));
        // 3.拼接key
        String key = USER_SIGN_KEY + userId + ":" + now;
        // 4.利用redis的bitmap操作，将当前日期所在offset 置为1
        int offset = LocalDateTime.now().getDayOfMonth();
        Boolean isSign = stringRedisTemplate.opsForValue().setBit(key, offset, true);//这里用的是Boolean类型，可以节省内存空间
        return Boolean.TRUE.equals(isSign) ? Result.ok("签到成功") : Result.fail("签到失败");
    }

    @Override
    public Result signCount() {
        //1.获取当前登录用户
        Long userId = UserHolder.getUser().getId();
        // 2.获取当前日期
        LocalDateTime now = LocalDateTime.now();
        // 3.拼接key
        String key = USER_SIGN_KEY + userId + ":" + now.format(DateTimeFormatter.ofPattern("yyyyMM"));
        // 4.获取今天是本月的第几天
        int dayOfMonth = now.getDayOfMonth();
        // 5.从reids中获取该用户的签到数据
        // BITFIELD sign:5:202203 GET u14 0
        List<Long> result = stringRedisTemplate.opsForValue().bitField(
                key,
                BitFieldSubCommands.create().
                        get(BitFieldSubCommands.BitFieldType.unsigned(dayOfMonth)).valueAt(0));
        if (result == null || result.isEmpty()) {
            // 没有任何签到结果
            return Result.ok(0);
        }
        // 6.从result中获取签到结果,算出本月签到的总天数
        int num = result.get(0).intValue();
        int sum=0;
        while(true){
            if(num == 0){
                break;
            }
            if((num&1)!=0){
                sum++;
            }
            num = num>>1;
        }
        return Result.ok(sum);
    }

    @Override
    public Result signCountContinuous() {
        // 1.获取当前用户id
        Long userId = UserHolder.getUser().getId();
        // 2.获取当前日期
        LocalDateTime now = LocalDateTime.now();
        // 3.拼接key
        String key = USER_SIGN_KEY + userId + ":" + now.format(DateTimeFormatter.ofPattern("yyyyMM"));
        // 4.获取今天是本月的第几天
        int dayOfMonth = now.getDayOfMonth();
        // 5.从reids中获取该用户的签到数据
        // BITFIELD sign:5:202203 GET u当前day 0
        List<Long> result = stringRedisTemplate.opsForValue().bitField(
                key,
                BitFieldSubCommands.create().
                        get(BitFieldSubCommands.BitFieldType.unsigned(dayOfMonth)).valueAt(0));
        if (result == null || result.isEmpty()) {
            // 没有任何签到结果
            return Result.ok(0);
        }
        // 6.从result中获取签到结果,算出最新的连续签到天数
        long num = result.get(0);
        int sum=0;
        for(int i=dayOfMonth;i>0;i--){
            if((num&1)==0){
                break;
            }
            sum++;
            num = num>>>1;// >>>可以保证无符号
        }
        return Result.ok(sum);
    }

    private User createUserWithPhone(String phone) {
        User user = new User();
        user.setPhone(phone);
        user.setNickName("user_" + RandomUtil.randomString(10));
        //保存用户,Mybatis plus的便捷方式
        save(user);
        return user;
    }
}
