package com.hmdp.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.util.StrUtil;
import com.hmdp.dto.Result;
import com.hmdp.dto.UserDTO;
import com.hmdp.entity.Blog;
import com.hmdp.entity.Follow;
import com.hmdp.entity.ScrollResult;
import com.hmdp.entity.User;
import com.hmdp.mapper.BlogMapper;
import com.hmdp.service.IBlogService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.hmdp.service.IFollowService;
import com.hmdp.utils.UserHolder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.core.ZSetOperations;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import static com.hmdp.utils.RedisConstants.BLOG_LIKED_KEY;
import static com.hmdp.utils.RedisConstants.FEED_KEY;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author 虎哥
 * @since 2021-12-22
 */
@Service
public class BlogServiceImpl extends ServiceImpl<BlogMapper, Blog> implements IBlogService {

    @Autowired
    private UserServiceImpl userService;
    @Autowired
    private IFollowService followService;
    @Autowired
    private StringRedisTemplate stringRedisTemplate;

    @Override
    public Result saveBlog(Blog blog) {
        // 1.获取登录用户
        UserDTO user = UserHolder.getUser();
        blog.setUserId(user.getId());
        // 2.保存探店博文
        boolean isSuccess = save(blog);
        if (!isSuccess) {
            return Result.fail("新增笔记失败！");
        }
        // 3.获取关注了自己的粉丝id
        List<Follow> ids = followService.query().eq("follow_user_id", user.getId()).list();
        // 4.将blogId记录到每个粉丝对应的收件箱
        ids.forEach(follow -> {
            stringRedisTemplate.opsForZSet().add(FEED_KEY+ follow.getUserId(), blog.getId().toString(), System.currentTimeMillis());
        });
        return Result.ok(blog.getId());
    }

    @Override
    public Result queryBlogById(Long  id) {
        //1.查询笔记
        Blog blog = getById( id);
        if (blog == null) {
            return Result.fail("笔记不存在！");
        }

        // 2.查询blog的作者头像与昵称
        queryBlogUser(blog);
        // 3.查询blog是否被点赞
        queryBlogIsLiked(blog);
        return Result.ok(blog);
    }

    @Override
    public Result likeBlog(Long id) {
        // 1.获取登录用户
        Long userId = UserHolder.getUser().getId();
        // 2.利用redis判断当前登录用户是否已经点赞
        String key = BLOG_LIKED_KEY + id;
        Double score = stringRedisTemplate.opsForZSet().score(key, userId.toString());
        if (score == null) {
            // 3.如果未点赞，可以点赞
            // 3.1.数据库点赞数 + 1
            boolean isSuccess = update().setSql("liked = liked + 1").eq("id", id).update();
            // 3.2.保存用户到Redis的set集合  zadd key value score
            if (isSuccess) {
                stringRedisTemplate.opsForZSet().add(key, userId.toString(), System.currentTimeMillis());
            }
        } else {
            // 4.如果已点赞，取消点赞
            // 4.1.数据库点赞数 -1
            boolean isSuccess = update().setSql("liked = liked - 1").eq("id", id).update();
            // 4.2.把用户从Redis的set集合移除
            if (isSuccess) {
                stringRedisTemplate.opsForZSet().remove(key, userId.toString());
            }
        }
        return Result.ok();
    }

    @Override
    public Result queryBlogLikesRank(Long id) {
        //按点赞的时间戳（value）倒序排序,只显示前三个点赞的用户
        String key = BLOG_LIKED_KEY + id;
        Set<String> top3 = stringRedisTemplate.opsForZSet().range(key, 0, 2);
        if (top3 == null || top3.isEmpty()) {
            return Result.ok();
        }
        List<Long> ids = top3.stream().map(Long::valueOf).collect(Collectors.toList());
        //注意：不要直接用getByIds，因为mybatisPlus提供的该方法是直接in，查询出来的结果不是点赞顺序，而是用户id排名,所以要自己手动编写
        String idStr = StrUtil.join(",", ids);
        List<UserDTO> userDTOS = userService.query().in("id", ids).last("ORDER BY FIELD(id," + idStr + ")").list()
                .stream()
                .map(user -> BeanUtil.copyProperties(user, UserDTO.class))//User映射成UserDTO
                .collect(Collectors.toList());
        return Result.ok(userDTOS);
    }

    @Override
    public Result queryFollowBlog(Long max, Integer offset) {
        //1.获取当前用户
        Long userId = UserHolder.getUser().getId();
        //2.从对应的收件箱分页读取笔记id
        String key = FEED_KEY + userId;
        Set<ZSetOperations.TypedTuple<String>> typedTuples = stringRedisTemplate.opsForZSet()
            .reverseRangeByScoreWithScores(key, 0, max, offset, 3);
        if (typedTuples == null || typedTuples.isEmpty()) {
            return Result.ok();
        }
        // 3.一个一个读取，并记录offset和 max
        List<Long> ids = new ArrayList<>(typedTuples.size());//直接创建足够的空间
        long minTime = 0;
        int os = 1;
        for (ZSetOperations.TypedTuple<String> tuple : typedTuples) {
            // 3.1.获取id
            ids.add(Long.valueOf(tuple.getValue()));
            // 3.2.获取分数(时间戳）
            long time = tuple.getScore().longValue();
            if(time == minTime){
                os++;
            }else{
                minTime = time;
                os = 1;
            }
        }
        // 4.根据id查询blog,注意顺序
        String idStr = StrUtil.join(",", ids);
        List<Blog> blogs = query().in("id", ids).last("ORDER BY FIELD(id," + idStr + ")").list();
        blogs.forEach(blog -> {
            // 4.1.查询blog的作者头像与昵称
            queryBlogUser(blog);
            // 4.2.查询blog是否被点赞
            queryBlogIsLiked(blog);
        });

        return Result.ok(new ScrollResult(blogs,minTime, os));
    }

    private void queryBlogIsLiked(Blog blog) {
        // 1.获取登录用户
        Long userId = UserHolder.getUser().getId();
        if(userId == null){
            return;
        }
        // 2.判断当前用户是否点赞
        String key = BLOG_LIKED_KEY + blog.getId();
        Double score = stringRedisTemplate.opsForZSet().score(key, userId.toString());
        //有score，则表示已点赞,将isLike设置为true
        blog.setIsLike(score != null);
    }

    private void queryBlogUser(Blog blog) {
        //展示用户的头像和昵称
        Long userId = blog.getUserId();
        User user = userService.getById(userId);
        blog.setIcon(user.getIcon());
        blog.setName(user.getNickName());
    }
}
