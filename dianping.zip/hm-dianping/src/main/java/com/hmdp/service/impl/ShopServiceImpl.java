package com.hmdp.service.impl;

import cn.hutool.core.util.StrUtil;
import cn.hutool.json.JSONUtil;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.hmdp.dto.Result;
import com.hmdp.entity.Shop;
import com.hmdp.mapper.ShopMapper;
import com.hmdp.service.IShopService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.hmdp.utils.CacheUtil;
import com.hmdp.utils.RedisData;
import com.hmdp.utils.SystemConstants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.geo.Circle;
import org.springframework.data.geo.Distance;
import org.springframework.data.geo.GeoResult;
import org.springframework.data.geo.GeoResults;
import org.springframework.data.redis.connection.RedisGeoCommands;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.domain.geo.GeoReference;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import static com.hmdp.utils.RedisConstants.*;
import static java.lang.Thread.sleep;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author 虎哥
 * @since 2021-12-22
 */
@Service
public class ShopServiceImpl extends ServiceImpl<ShopMapper, Shop> implements IShopService {

    @Autowired
    private StringRedisTemplate stringRedisTemplate;
    @Autowired
    private CacheUtil  cacheUtil;
    @Autowired
    private IShopService shopService;

    private static final ExecutorService  executor = Executors.newFixedThreadPool(10);
    @Override
    public Result queryById(Long id) throws InterruptedException {
        //缓存穿透
        //缓存雪崩
        //缓存击穿
        Shop shop=cacheUtil.getWithLogicalExpire(id, Shop.class, CACHE_SHOP_KEY, CACHE_SHOP_TTL, TimeUnit.MINUTES, this::getById);
        if(shop==null){
            return Result.fail("店铺不存在");
        }
        return Result.ok(shop);
    }

    @Override
    public Result update(Shop shop) {
        //1.先操作数据库
        Long id=shop.getId();
        if(id==null){
            return Result.fail("店铺id不能为空");
        }
        updateById(shop);
        //2.再删除redis原先的缓存
        stringRedisTemplate.delete(CACHE_SHOP_KEY+id);
        return Result.ok();
    }

    @Override
    public Result queryShopByType(Integer typeId, Integer current, Double x, Double y) {
        if(x==null||y==null){
            // 直接根据类型分页查询，不按距离排序
            Page<Shop> page = shopService.query()
                    .eq("type_id", typeId)
                    .page(new Page<>(current, SystemConstants.DEFAULT_PAGE_SIZE));
            // 返回数据
            return Result.ok(page.getRecords());
        }
        // 计算分页
        int from=(current-1)*SystemConstants.DEFAULT_PAGE_SIZE;
        int end=current*SystemConstants.DEFAULT_PAGE_SIZE;
        //从redis的GEO中查询5公里内的店铺id
        String key=SHOP_GEO_KEY+typeId;
        GeoResults<RedisGeoCommands.GeoLocation<String>> results = stringRedisTemplate.opsForGeo() // GEOSEARCH key BYLONLAT x y BYRADIUS 10 WITHDISTANCE
                .search(
                        key,
                        GeoReference.fromCoordinate(x, y),
                        new Distance(5000),
                        RedisGeoCommands.GeoSearchCommandArgs.newGeoSearchArgs().includeDistance().limit(end)
                );
        if(results==null){
            return Result.ok(Collections.emptyList());
        }
        // 解析结果
        List<GeoResult<RedisGeoCommands.GeoLocation<String>>> locations = results.getContent();
        // 已经达到最大数量，下次下滑无法再获取
        if(locations.size()<=from){
            return Result.ok(Collections.emptyList());
        }
        List<Long> ids = locations.stream()
                .map(m -> Long.valueOf(m.getContent().getName()))
                .toList();
        List<Shop> list = shopService.listByIds(ids)// 查询符合的店铺
                .stream()
                .sorted(Comparator.comparingDouble(Shop::getDistance))// 根据距离排序
                .toList();
        // 给每个店铺添加距离字段
        for (Shop shop : list) {
            shop.setDistance(locations.get(ids.indexOf(shop.getId())).getDistance().getValue());
        }
        // 返回分页数据，每次只返回（end-from）一页的数据
        return Result.ok(list.subList(from, Math.min(end, list.size())));
    }
}
